import RPi.GPIO as GPIO
from picamera import PiCamera
import time
from time import sleep
import requests
import json
import http.client
import timeit
import datetime

    

ir_pin = 11
camera = PiCamera()


GPIO.setmode(GPIO.BOARD)
#GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(ir_pin , GPIO.IN)

# LED setup   ==============================
#import RPi.GPIO as GPIO
#import time

#GPIO.setmode(GPIO.BCM)
#GPIO.setwarnings(False)

led_green = 26
led_red = 13
led_yellow = 19


GPIO.setup(led_green,GPIO.OUT)
GPIO.setup(led_red,GPIO.OUT)
GPIO.setup(led_yellow,GPIO.OUT)

def led(col,sec):

    GPIO.output(led_green,False)
    GPIO.output(led_red,False)
    GPIO.output(led_yellow,False)

    if col == led_green or col== led_red or col== led_yellow:
       print (str(col) + ' LED ON')
       GPIO.output(col,True)
       sleep(sec)
    elif col == "all":
       print (col + ' LED OFF')
       
       GPIO.output(led_green,False)
       GPIO.output(led_red,False)
       GPIO.output(led_yellow,False)
       

# WAITING FOR IMAGE                        green
# WAIT FOR ANALYSIS TO HAPPEN ON DCR       YELLOW
# IN CASE OF WRONG IMAGE - TO RESCAN       red

# If good                   Green
# if undertermined          yellow
#   missing green or white  red



led(led_green,1)

led(led_red,1)
led(led_yellow,1)

led("all",1)

#  LED SETUP complete  ====================




while True:     #    continous loop

 # led(led_green,blink)    #  mesage to worker - waiting forimage

         
        
 while True:    # loop to detect movement

    
    if (0 == GPIO.input(ir_pin)):        #  movement detected  
        #led(led_yellow,blink)
        #camera.resolution = (64, 64)
        #camera.resolution = (128, 128)
        camera.resolution = (256, 256)
        # camera.resolution = (2592, 1944)
        camera.start_preview()
        sleep(2)
        camera.capture('/home/pi/RaspDCR_IoT_Py/123DCR.jpg')
        camera.stop_preview()
       
        
        break
        
    if (0 != GPIO.input(ir_pin)):
       
        print ('Waiting');
        
        
 start = timeit.timeit()
 print ("hello")

 # Upoad to GDrive
 token = "Bearer ya29.c.El_gBU9W51pByx5qlo5Di2iqF8lFasScVBPgdA86g4UEQI-viF2E-BI0RgExbfmSRNQ2DAp1q00f180CyocszCYl_9VWSjrIQ3qMS62-1u8U4l9WQh4cZEQsxAEaGc-FHw"

 conn = http.client.HTTPSConnection("www.googleapis.com")

 #payload = "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"\"; filename=\"1502297193_basler270.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--"

 payload = open('123DCR.jpg','rb')
 

 headers = {
    'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
    'authorization': token,
    'cache-control': "no-cache"
    # ,'postman-token': "2e785548-2047-78b0-1713-90622fdab0a7"
    }
 i=time.time()
 j=str(i)
 filename = j +".jpg"
 print(filename)
 
 conn.request("POST", '/upload/storage/v1/b/sapphire-2018-vcm/o?uploadType=media&name='+filename+'' , payload, headers)

 res = conn.getresponse()
 data = res.read()

 print(data.decode("utf-8"))


 # Get Results

 url = 'https://alpha-vision.googleapis.com/v1/images:annotate'

 payload = {
  "requests": [
 
    {
      "image": {
        "source": {
          "gcsImageUri":
              'gs://sapphire-2018-vcm/'+filename+''
        }
      },
      "features": [
        {"type": "CUSTOM_LABEL_DETECTION", "maxResults": 10 },
        {"type": "LABEL_DETECTION", "maxResults": 10 }
      ],
       "customLabelDetectionModels":
          "projects/sapphire-2018/models/Sapphire_2018_DCR/versions/Sapphire_2018_DCR_v1_20180527"
     }
   ]
 }


 headers = {
  #  'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
    'authorization': token,
    # ,'postman-token': "2e785548-2047-78b0-1713-90622fdab0a7"
    }

 response = requests.post(url, headers = headers, data = json.dumps(payload))

 print(response.status_code)
 print(response.text)

 resJSON = json.loads(response.text);

 print(resJSON['responses'][0]['customLabelAnnotations'])

 resultsArr = resJSON['responses'][0]['customLabelAnnotations']


 end = timeit.timeit()
 print ((end - start)*1000)
#handle LEDs  ===============
 if( resultsArr[0]['score'] > 0.8 ):
    label = resultsArr[0]['label']
    
    
    if label == "GOOD":
       led(led_green,5)
       print(label) 
       
    else:led(led_red,5)
    print(label) 
    
    
 else:
     label = 'Undetermined'
     print(label) 
     led(led_yellow,5)
     
 
         
 
 led("all",1)
 print("second api calling")

 response1 = requests.post(url, headers = headers, data = json.dumps(payload))
 print(response1.status_code)
 print(response1.text)

 resJSON = json.loads(response1.text);

 print(resJSON['responses'][0]['customLabelAnnotations'])

 resultsArr = resJSON['responses'][0]['customLabelAnnotations']
 print("second api result displayed")

 #end of handle LEDs ===========


 r = requests.get('https://fsm-sapmqttconnect-microservice-dev.run.aws-usw02-pr.ice.predix.io/returnGoogleData/Visual_S3A/Basler_Vision_Kit/'+label+'')


