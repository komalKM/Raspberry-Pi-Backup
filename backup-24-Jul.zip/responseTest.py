import json

# response assign to result

result = {'responses': [{'customLabelAnnotations': [{'model': '/projects/sapphire-2018/models/VisionaAPIWithBlurImages/versions/VisionaAPIWithBlurImages_201806252018_base', 'score': 0.992394, 'label': 'BLUR'}, {'model': '/projects/sapphire-2018/models/VisionaAPIWithBlurImages/versions/VisionaAPIWithBlurImages_201806252018_base', 'score': 0.9743643, 'label': 'a_90'}, {'model': '/projects/sapphire-2018/models/VisionaAPIWithBlurImages/versions/VisionaAPIWithBlurImages_201806252018_base', 'score': 0.5498249, 'label': 'MISSING_WHITE'}]}]}

# 

# list the orientation labels
# list the assembly quality  labels
# list image quality ( Blur and Normal)

# list valid logos

# orientation= ['a_180', ''

# read labels
#fr each label

#if label relates to orientation and percentage > limit
       #orientation = current label
#else if label relates to assembly quality and percentage > limit
       #assembly quality = current label
#else if label relates to image quality and percentage > limit
       #image quality = current label



#print oriantation
#pint assembly quality
#pint image quality

#a= json.dumps(result)
#print(result)

limit = 0.7

orientation = ['NORMAL','a_180','a_270','a_90']
image_quality = ['BLUR']
assembly_quality = ['GOOD','MISSING_GREEN','MISSING_WHITE']
out= len(result['responses'][0]['customLabelAnnotations'])

image_quality_label=""
orientation_label=""
assembly_quality_label=""


print(out)

for x in range(out):
       label= result['responses'][0]['customLabelAnnotations'][x]['label']
       score = result['responses'][0]['customLabelAnnotations'][x]['score']
       
       if (label in orientation ) :
              
              if (score > limit):
                     orientation_label = label
                     print(orientation_label)
              else :
                     print("undetermined")
       if (label in image_quality ) :
             
              if (score > limit):
                     image_quality_label = label
                     print(image_quality_label)
              else :
                     print("Good")
       if (label in assembly_quality ) :
              s
              if (score > limit):
                     assembly_quality_label = label
                     print(assembly_quality_label)
              else :
                     print("Undetermined")  

       
              
           
#for y in range(out):
 #      label=result['responses'][0]['customLabelAnnotations'][y]['label']
  #
  
      # if (label in image_quality ) :
       #       score = result['responses'][0]['customLabelAnnotations'][y]['score']
        #      if (score > limit):
         #            print(result['responses'][0]['customLabelAnnotations'][y]['label'])
          #    else :
           #          print("Good")           
      
       
           
#for z in range(out):
 #      label=result['responses'][0]['customLabelAnnotations'][z]['label']
  #     
   #    if (label in assembly_quality ) :
    #          score = result['responses'][0]['customLabelAnnotations'][z]['score']
     #         if (score > limit):
      #               print(result['responses'][0]['customLabelAnnotations'][z]['label'])
       #       else :
        #             print("Undetermined")
        limit = 0.7

        orientation = ['NORMAL','a_180','a_270','a_90']
        image_quality = ['BLUR']
        assembly_quality = ['GOOD','MISSING_GREEN','MISSING_WHITE']
        out= len(result['responses'][0]['customLabelAnnotations'])

        print(out)
        for x in range(out):
                label=result['responses'][0]['customLabelAnnotations'][x]['label']
        if (label in orientation ) :
                score = result['responses'][0]['customLabelAnnotations'][x]['score']
                if (score > limit):
                        orientation_label = result['responses'][0]['customLabelAnnotations'][x]['label']
                        print(orientation_label)
                else :
                        print("undetermined")
        else :
                print("Label not found")
                orientation_label="Undetermined"
        if (label in image_quality ) :
                score = result['responses'][0]['customLabelAnnotations'][x]['score']
                if (score > limit):
                       image_quality_label = result['responses'][0]['customLabelAnnotations'][x]['label']
                       print(image_quality_label)
                else :
                       print("Good")
        else :
                print("Label not found")
                image_quality_label="Undetermined"
        if (label in assembly_quality ) :
                score = result['responses'][0]['customLabelAnnotations'][x]['score']
                if (score > limit):
                       assembly_quality_label = result['responses'][0]['customLabelAnnotations'][x]['label']
                       print(assembly_quality_label)
                else :
                       print("Undetermined")
        else :
                print("Label not found")
                assembly_quality_label="Undetermined"
