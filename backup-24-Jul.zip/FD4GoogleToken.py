import requests
import json

def token():
 r = requests.post(
    'https://www.googleapis.com/oauth2/v4/token',
    headers={'content-type': 'application/x-www-form-urlencoded'},
    data={
        'grant_type': 'refresh_token',
        'client_id': '472917963037-l4sbd1ttcv31qr7olqam6rihe2266jpk.apps.googleusercontent.com',
        'client_secret': 'H1SFaKKL3SniGsijGMMxadAJ',
        'refresh_token': '1/EHAHhkeINSu3jeci-4RomoFYD2q6qyLxp2uUPp2zD0Q',
    }
 )
 resJson= json.loads(r.text)
 print(resJson['access_token'])
