import time
import paho.mqtt.client as paho
import FD4LIB
import json

broker="m13.cloudmqtt.com" #Free CloudMQTT account domain
username = "uctiuqld"      #Username for CloudMQTT Broker
password = "WwQsrtwI15a4"  #Password for CloudMQTT Broker

temperature = "0"

#define callback
print("1")
def on_connect(client, userdata, flags, rc):
    #print("Connected with result code "+str(rc))
    pass

def on_message(client, userdata, message):
    time.sleep(1)
    
    #print("received message =",str(message.payload.decode("utf-8")))
    received_message = json.loads(str(message.payload.decode("utf-8")))
    
    print(received_message)

    try :
        temperature = received_message['messages'][0]['Temperature']
    except :
        
        temperature = ""
    print(temperature)

    if (temperature  == "35"):
               FD4LIB.start_LED("red")
    else:
               FD4LIB.start_LED("")

    #payload = {"mode":"sync","messageType":"474f0487ed0c8f833ccb","messages":[{"Temperature":"25"}]} #Define Payload
    #print("publishing ")
    #client.publish("iot/data/iotmmsp1942077485trial/v1/c374212b-7ec3-4fb3-88db-1793cec8db4c", str(payload))#Publish 

    time.sleep(4)
    ##print(message.topic+" "+str(message.payload))
def on_publish(client, userdata, mid):
    print("Published to client", str(client))
    
client= paho.Client("Not Needed") 

print("2")

getResult=""

try:
        getResult = str(message.payload.decode("utf-8"))
except:
        print("Message not Received")
####set username and password from cloudmqtt server

client.username_pw_set(str(username), password= password )

print("3")
client.on_message=on_message
client.on_connect=on_connect
client.on_publish=on_publish

while True:
    ######Bind functions to callback

    #####
    print("connecting to broker ",broker)
    client.connect(broker, 16988, 60)#connect
    client.loop_start() #start loop to process received messages
    print("subscribing ")
    client.subscribe("iot/log/iotmmsp1942077485trial/v1/c374212b-7ec3-4fb3-88db-1793cec8db4c")  #subscribe to log
    client.subscribe("iot/ack/iotmmsp1942077485trial/v1/c374212b-7ec3-4fb3-88db-1793cec8db4c")  #subscribe to acknowledge
    client.subscribe("iot/push/iotmmsp1942077485trial/v1/c374212b-7ec3-4fb3-88db-1793cec8db4c") #subscribe to push
    time.sleep(2)
    print("4")


    print("X,",getResult,"X")

    if (temperature  == "35"):
               FD4LIB.start_LED("red")
    else:
               FD4LIB.start_LED("")

    #payload = {"mode":"sync","messageType":"474f0487ed0c8f833ccb","messages":[{"Temperature":"25"}]} #Define Payload
    #print("publishing ")
    #client.publish("iot/data/iotmmsp1942077485trial/v1/c374212b-7ec3-4fb3-88db-1793cec8db4c", str(payload))#Publish 

    time.sleep(4)

    
#print("published successfully")


client.disconnect() #disconnect
client.loop_stop() #stop loop
