import pygame,sys
from pygame.locals import *
import pygame.camera
import time
import base64

import requests
 
def datatoS4(product,workstation,imageEncoded , timestamp) :
    url = "https://m16virtual.apimanagement.hana.ondemand.com:443/ZFILE_IMPORT_SRV/ImageSet"
 
    payload = {
                "d": {
                               
                                "Workstation": "MyWS11334",
                                "Product": "LENOVO12343",
                                "Timestamp": "20180711113333",
                                "Imagebase64": "U0drZ2FTQmhiU0JUUVZBZ1FVSkJVQ0JEYjI1emRXeDBZVzUw"
                 }
     }
    headers = {
    'authorization': "Basic aG11bmRyYTpmZDQxMjM=",
    'content-type': "application/json",
    'x-csrf-token': "Fetch",
    'cache-control': "no-cache",
    'postman-token': "5f3040e9-2fe0-69ec-23a5-8e35bd771556"
    }
    s= requests.Session()
    response = s.request("GET", url, data=payload, headers=headers)
    token = response.headers['x-csrf-token']
 
    print(token)

    payload = '{"d": {"Workstation": "'+workstation+'","Product": "'+product+'","Timestamp": "'+timestamp+'","Imagebase64": "'+imageEncoded+'"}}'
    headers1 = {
    'authorization': "Basic aG11bmRyYTpmZDQxMjM=",
    'content-type': "application/json",
    'x-csrf-token': token,
    'cache-control': "no-cache",
    
    }
 
    response1 = s.request("POST", url, data=payload, headers=headers1)
 
    print(response1.text)
    print(response1.status_code)

    
def convertimage(imagename):
  
    with open(imagename, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    return(encoded_string)




epoch_time = int(time.time())
epoch_time1= str(epoch_time)
pygame.init()
pygame.camera.init()
cam = pygame.camera.Camera("/dev/video0",(256,256))
cam.start()
image= cam.get_image()
pygame.image.save(image,'DCR123.jpg')

imagebase64 = convertimage("DCR123.jpg")
print(imagebase64)
convertedtext = str(imagebase64)
str1= convertedtext.lstrip("b'")
convertedImage= str1.rstrip("'")

a= datatoS4("IoTLab","Abhishek1",convertedImage , epoch_time1)

cam.stop()
