import requests
 
url = "https://alpha-vision.googleapis.com/v1/images:annotate"
 
payload = "{\r\n  \"requests\": [\r\n\r\n    {\r\n      \"image\": {\r\n       \"source\": {\r\n          \"gcsImageUri\":\r\n              \"gs://sapphire-2018-vcm/download.png\"\r\n        }\r\n\r\n      },\r\n      \"features\": [\r\n                   {\"type\": \"LOGO_DETECTION\", \"maxResults\": 10},\r\n         {\"type\": \"TEXT_DETECTION\", \"maxResults\": 10},\r\n          {\"type\": \"CUSTOM_LABEL_DETECTION\", \"maxResults\": 10 },\r\n        {\"type\": \"LABEL_DETECTION\", \"maxResults\": 10 }\r\n                \r\n     \r\n      ],\r\n      \"customLabelDetectionModels\":\r\n          \"projects/sapphire-2018/models/VisionaAPIWithBlurImages/versions/VisionaAPIWithBlurImages_201806252018_base\"\r\n    }\r\n  ]\r\n}\r\n"
headers = {
    'authorization': "Bearer  ya29.GlzwBd5xjZf_wlb--fTYRpE2_Tm75zdDtyEzAo4N25RsiNip_8trP2tpPhU40MpR2g1gCl429YHCcM1Wv4UYuLSRL_Jxe0tqkxWELicZCKNUaF7rnyCpz5CQFHqE0Q",
    'cache-control': "no-cache",
    'postman-token': "01bc1481-0184-fb65-6f3d-171a9572998d"
    }
 
response = requests.request("POST", url, data=payload, headers=headers)
 
print(response.text)




    
