import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

LED_green = 24
led_red = 23
led_white = 18

GPIO.setup(LED_green,GPIO.OUT)
GPIO.setup(led_red,GPIO.OUT)
GPIO.setup(led_white,GPIO.OUT)

print ('LED ON')
GPIO.output(LED_green,True)
GPIO.output(led_red,True)
GPIO.output(led_white,True)

time.sleep(5)
print ('LED OFF')
GPIO.output(LED_green,False)
GPIO.output(led_red,False)
GPIO.output(led_white,False)

