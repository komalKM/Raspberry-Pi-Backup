import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

led_green = 36
led_red = 40
led_yellow = 38

led = input("enter color")

GPIO.setup(led_green,GPIO.OUT)
GPIO.setup(led_red,GPIO.OUT)
GPIO.setup(led_yellow,GPIO.OUT)

GPIO.output(led_green,False)
GPIO.output(led_red,False)
GPIO.output(led_yellow,False)

if led == "green":
    print ('LED ON')
    GPIO.output(led_green,True)
elif led == "red":
    GPIO.output(led_red,True)
elif led == "yellow":
    GPIO.output(led_yellow,True)
    



