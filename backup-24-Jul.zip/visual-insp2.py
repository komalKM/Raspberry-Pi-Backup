
import FD4LIB
import time
import FD4Google
import socket
import json
import FD4DatatoS4
 

#Wait til network is ready to start the demo 
FD4LIB.check_internet()

print("Motor started")
FD4LIB.motor("Start")
            

while True:
        print ('Detecting next product in inspection zone');
        FD4LIB.detectmotion()
        print ('Next Product Detected.. ');
        FD4LIB.start_LED("yellow")
        time.sleep(0.5)
        FD4LIB.motor("Stop")
       
        FD4LIB.capture("start")
        print("Image clicked, processing the image,  Please Wait \n")

       
        epoch_time = int(time.time())
        epoch_time1 = str(epoch_time)
        

        # extract  the information received from the image using Google Cloud APIs
        logo_result= FD4Google.getlogo("DCR123.jpg")

        
        
       
        result=FD4Google.AnalyzeImage("DCR123.jpg")
        #print(result,"\n\n\n")

        #converting Image from JPG to base64 and sending to IoT in Binary format
        imagebase64 = FD4Google.convertimage("DCR123.jpg")
        convertedtext = str(imagebase64)
        str1= convertedtext.lstrip("b'")
        convertedImage= str1.rstrip("'")
        
        # Sending Data to s/4 hana Image, station and product
        FD4DatatoS4.datatoS4("Basler Vision Kit","Visual Station S3A",convertedImage , epoch_time1)

        #Extracting Logo from Image using Google cloud API'S

        try :
                logo = logo_result[0]['description']
        except :
                logo="NA"
        

        # Extracting text detected coordinates from the image using Google Cloud Text Detection API

        try:
                textCoordinates = str(result['responses'][0]['textAnnotations'][0]['boundingPoly'])
                
        except:
                textCoordinates=""
      

        # Extracting logo detected coordinates from the image using Google Cloud Logo Detection API

        try:
                logoCoodinates = str(logo_result[0]['boundingPoly'])
                
        except:
                logoCoodinates="Undetermined"
        

        
        label_detected={}
        
        label_detected=FD4Google.AnalyzeLabels(result)

        print("Logo :\t\t", logo )
        

        for  n in list(label_detected.keys()):
                print(n,"  :\t", label_detected[n])

        
        try :
                assembly_quality=label_detected['assembly_label']
        except :
                assembly_quality ="Undetermined"
                
        try :
                text = label_detected['text_detected']

                
                
        except:
                text=""
        try :
                orientation = label_detected['orientation_label']
        except :
                orientation = "Undetermined"
        try :
                image_quality = label_detected['image_label']
        except :
                
                image_quality="Undetermined"
        

        token=FD4Google.generateToken()

        base64_image = FD4Google.convertimage("DCR123.jpg")
        
        if text  == "2000281-5":
                 print("Sr No 2000281-5 is not a valid serial number of this order, please remove the job")
                 FD4LIB.start_LED("red")
                 time.sleep(8)
                 FD4LIB.start_LED("none")
        elif  image_quality  == "BLUR":
                 print("Job shape/Form factor is incorrect, please remove the job")
                 FD4LIB.start_LED("red")
                 time.sleep(8)
                 FD4LIB.start_LED("none")
        else:
                 print("Job Accepted")
                 FD4LIB.start_LED("green")
                 time.sleep(8)
                 FD4LIB.start_LED("none")

     

        #Display LED
        #FD4Google.DisplayLED(imageResult)
        
        
        #Upload to SAP Leonardo IoT
        #uploadtoIoT(Thing,ProductObserved,Result,AssemblyOrientation,Assembly_Shape,Assembly_Quality,Bearer_Token,URL,Base64,SerialNo,Logo)
        
        
        FD4Google.uploadtoIoT("Visual Station S3A","Basler Vision Kit",textCoordinates,orientation,image_quality,assembly_quality,token,logoCoodinates,epoch_time1,text,logo)
        print ("======================================\n\n")
        #Display the results on image========================
        # On screen - Display image  - Display Logo,  Display Labels,  Display Text(Serial Number)
        #print("Actual meeages have been commented our temporarily")
        #print("\n\nProduct Logo       :",logo)
        #print("Product Serial no. :",text)
        #print("Inspection Result  :" , imageResult[0]['label'],"\n\n\n")

        
        # Restart the turn table o take next item for inspection
        
        FD4LIB.motor("Start")
        FD4LIB.start_LED("none")
        #print("waiting for product to pass out of inspection zone")
        time.sleep(1)
              
     
        
        



        


        

    


