import time
import paho.mqtt.client as paho

#broker="m20.cloudmqtt.com" #Free CloudMQTT account domain
 #username = "uctiuqld"      #Username for CloudMQTT Broker
#password = "WwQsrtwl15a4"  #Password for CloudMQTT Broker

broker="m20.cloudmqtt.com" #Free CloudMQTT account domain
username = "ynnkgutv"      #Username for CloudMQTT Broker
password = "2dTk9j7uDwMo" 

#define callback
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
def on_message(client, userdata, message):
    time.sleep(1)
    print("received message =",str(message.payload.decode("utf-8")))
    ##print(message.topic+" "+str(message.payload))
def on_publish(client, userdata, mid):
    print("Published to client", str(client))
    
client= paho.Client("Not Needed") 

####set username and password from cloudmqtt server

client.username_pw_set(username, password)   ## (str(username), password= password )

######Bind functions to callback
client.on_message=on_message
client.on_connect=on_connect
client.on_publish=on_publish

#####
print("connecting to broker ",broker)
client.connect(broker, 19772, 60)#connect 16988
client.loop_start() #start loop to process received messages
print("subscribing ")
client.subscribe("iot/log/iotmmsp1942077485trial/v1/be44ad28-febd-4093-9096-1559a612fe5c")  #subscribe to log
client.subscribe("iot/ack/iotmmsp1942077485trial/v1/be44ad28-febd-4093-9096-1559a612fe5c")  #subscribe to acknowledge
client.subscribe("iot/push/iotmmsp1942077485trial/v1/be44ad28-febd-4093-9096-1559a612fe5c") #subscribe to push
time.sleep(2)
payload = {"mode":"sync","messageType":"199eb35c674e0ba85071","messages":[{"tesmp":"Himank"}]} #Define Payload
print("publishing ")
client.publish("iot/data/iotmmsp1942077485trial/v1/be44ad28-febd-4093-9096-1559a612fe5c", str(payload))#Publish 

time.sleep(4)
print("published successfully")
client.disconnect() #disconnect
client.loop_stop() #stop loop

