import RPi.GPIO as GPIO
import FD4LIB
import time


Pin = 16

GPIO.setmode(GPIO.BOARD)
GPIO.setup(Pin , GPIO.IN, pull_up_down = GPIO.PUD_UP)

print("Motor started")
FD4LIB.motor("Start")



while True:
    try:
      if (0 != GPIO.input(Pin)):
        pass
        #print ('Fail');
      if (0 == GPIO.input(Pin)):
        print ('Detected.. Stop the motor');
        time.sleep(2)
        FD4LIB.motor("Stop")
       
        print("Image clicking")
        FD4LIB.capture("start")
        
        print("Image clicked")
        

        FD4LIB.motor("Start")
      else:
        print("None")

    except (KeyboardInterrupt, SystemExit):
      
        FD4LIB.motor("stop")
        print("Keyboard Interrupted")
        GPIO.cleanup()
        
        



        


        

    


