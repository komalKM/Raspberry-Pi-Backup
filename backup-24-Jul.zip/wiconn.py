import subprocess
import time


while True:
    ps = subprocess.Popen(['iwconfig'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    try:
       output = subprocess.check_output(('grep','ESSID'), stdin=ps.stdout)


    except subprocess.CalledProcessError:
       pass
       
    
    if ("off" in str(output)):
            print(output)
            print("Waiting for WiFi connecion. Please Check the network connectivity")
            time.sleep(2)
    else:
            print("Network connectivity: OK")
            break
      
    

