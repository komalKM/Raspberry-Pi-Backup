import sys
import time
import RPi.GPIO as GPIO

Forward = 11
sleeptime = 2

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(Forward,GPIO.OUT)

def forward(x):

    GPIO.output(Forward,1)
    print("motor start")
    #time.sleep(x)
    #GPIO.output(Forward,0)

while (1):
    forward(5)
    
