import time
import FD4LIB

       
while True:
    action = input("Enter Start or Stop")
    print(action)
    if action == "Start":
        print("motor started")
        FD4LIB.motor("Start")
        continue
    elif action == "Reverse":
        print("motor reversed")
        FD4LIB.motor("Reverse")
        continue
    elif action == "Stop":
        print("motor stopped")
        FD4LIB.motor("Stop")
        continue
    else:
        print("break")
        FD4LIB.motor("Close")
        break
       

