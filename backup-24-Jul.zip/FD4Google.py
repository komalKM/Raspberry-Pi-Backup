
# ==============Importing Libraries ==============================#
import base64
import requests
import json
import http.client
import timeit
import datetime
import RPi.GPIO as GPIO
import time
import paho.mqtt.client as paho

GPIO.setwarnings(False)


######========= configuring Mqtt Boker =================#####

broker="m13.cloudmqtt.com" #Free CloudMQTT account domain
username = "uctiuqld"      #Username for CloudMQTT Broker
password = "WwQsrtwI15a4"  #Password for CloudMQTT Broker

####============= Setting GPIO mode Board =====================####

GPIO.setmode(GPIO.BOARD)


#########========== Initializing Pin for LED's ===================######

led_green = 26
led_red = 13
led_yellow = 19

GPIO.setup(led_green,GPIO.OUT)
GPIO.setup(led_red,GPIO.OUT)
GPIO.setup(led_yellow,GPIO.OUT)



 

######### =======  Function to glow LED's ================#########


def led(col,sec):

    GPIO.output(led_green,False)
    GPIO.output(led_red,False)
    GPIO.output(led_yellow,False)

    if col == led_green or col== led_red or col== led_yellow:
       print (str(col) + ' LED ON')
       GPIO.output(col,True)
       time.sleep(sec)
    elif col == "all":
       print (col + ' LED OFF')
       
       GPIO.output(led_green,False)
       GPIO.output(led_red,False)
       GPIO.output(led_yellow,False)

       
######========= Function to get Logo from Image ===============#############
def getlogo(imagename):
    base64text = convertimage(imagename)
    convertedtext = str(base64text)
    str1= convertedtext.lstrip("b'")
    str2= str1.rstrip("'")
    
    
    #print(str2)

    url = "https://vision.googleapis.com/v1/images:annotate"

    querystring = {"key":"AIzaSyAyqwhl2RjGjB4LMeF6H2juT8Tz7zBYJU4"}

    payload = '{\r\n  \"requests\": [\r\n    {\r\n      \"image\": {\r\n        \"content\": \"'+str2+'"\r\n      },\r\n      \"features\": [\r\n        {\r\n          \"type\": \"LOGO_DETECTION\"\r\n        }\r\n      ]\r\n    }\r\n  ]\r\n}'
    headers = {
        'cache-control': "no-cache",
        'postman-token': "d1e06da2-f492-add4-4987-4e40bf35c1f0"
    }

    response = requests.request("POST", url, data=payload, headers=headers, params=querystring)


    #++++++++++++++++ Handle response to display using status code and povide description=

    #print(json.loads(response.text))

    #capture logo from the image response
    
    resJson=  json.loads(response.text)
    #logo= resJson['responses'][0]['logoAnnotations'][0]['description']
    

   
    try :
        logo= resJson['responses'][0]['logoAnnotations']
    except :
        logo="undetermined"
    #print(logo)
    return logo



############============== Function to get Text from Image =============###########333  
##   Need to be modified to send all text
    

def getText(image):
    base64Text = convertimage(image)
    convertedtext = str(base64Text)
    str1= convertedtext.lstrip("b'")
    str2= str1.rstrip("'")
    
    url = "https://vision.googleapis.com/v1/images:annotate"

    querystring = {"key":"AIzaSyCB5skX8Jk1WnOaP4NtnJQvwdfIgJlj3yA"}

    payload = '{\r\n  \"requests\": [\r\n    {\r\n      \"image\": {\r\n        \"content\": \"'+str2+'"\r\n      },\r\n      \"features\": [\r\n        {\r\n          \"type\": \"TEXT_DETECTION\"\r\n        }\r\n      ]\r\n    }\r\n  ]\r\n}'
    headers = {
    'content-type': "application/xml",
    'x-smp-appcid': "634e3a02-f6dc-414e-ae3b-13b023695ca3",
    'authorization': "Basic UDE5NDE5NTc0NDg6Q2FwZ2VtaW5pQDIxNTQ",
    'cache-control': "no-cache",
    'postman-token': "bdb63370-a5cb-a41a-a9fd-463e12ccc233"
    }

    response = requests.request("POST", url, data=payload, headers=headers, params=querystring)

    resJSON = json.loads(response.text)
    #print(resJSON)

   # if restjson.len != 0:
   #sr=str(resJSON['responses'][0]['textAnnotations'][0]['description'])
   #srno= woNo.strip("01")
   #print(srno)
    return "158234"

#########============= Function to convert Image to base64 =============######
    
def convertimage(imagename):
  
    with open(imagename, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    return(encoded_string)


######============Function to Generate Token ================###########

def generateToken():
 r = requests.post(
    'https://www.googleapis.com/oauth2/v4/token',
    headers={'content-type': 'application/x-www-form-urlencoded'},
    data={
        'grant_type': 'refresh_token',
        'client_id': '472917963037-jdg5al2birglolp7qmb016s9a4dlejsk.apps.googleusercontent.com',
        'client_secret': 'P-VqWeksIdoRdzUVkwuT8FV4',
        'refresh_token': '1/wImaRTSRlbV-r4r0ubZYN9urlgAclVJcYQ5qey44Pcg',
    }
 )
 resJson= json.loads(r.text)
 
 tokenGenerated = "Bearer " + resJson['access_token']
 #print(tokenGenerated)
 return tokenGenerated



########============== Function to upload Image to Google and Get Results ===============##########


def AnalyzeImage(imagename):
   
  # Upoad to GDrive
  token = generateToken()

  conn = http.client.HTTPSConnection("www.googleapis.com")

  payload = open(imagename,'rb')
 

  headers = {
    'content-type': "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
    'authorization': token,
    'cache-control': "no-cache"
    }
  i=time.time()
  j=str(i)
  filename = j +".jpg"
  #print(filename)
 
  conn.request("POST", '/upload/storage/v1/b/sapphire-2018-vcm/o?uploadType=media&name='+filename+'' , payload, headers)

  res = conn.getresponse()
  data = res.read()

  #print(data.decode("utf-8"))

  # Get Results

  url = 'https://alpha-vision.googleapis.com/v1/images:annotate'

  payload = {
   "requests": [
 
    {
      "image": {
        "source": {
          "gcsImageUri":
              'gs://sapphire-2018-vcm/'+filename+''
        }
      },
      "features": [
                   
       
          {"type": "CUSTOM_LABEL_DETECTION", "maxResults": 3 },
          {"type": "TEXT_DETECTION", "maxResults": 10 },
          {"type": "LOGO_DETECTION", "maxResults": 10 },
        
               
     
      ],
      "customLabelDetectionModels":
          "projects/sapphire-2018/models/VisionForGoogleNext/versions/VisionForGoogleN_v20180713061013"
    }
   ]
  }


  headers = {

    'authorization': token,

    }

  response = requests.post(url, headers = headers, data = json.dumps(payload))

  if response.status_code != 200:
      if response.status_code == 401:
          print("Error 401: Invalid Credentials - Refresh  or replace Token")
      elif response.status_code == 403:
          print("Error 403: Error Accessing Google Account")
      else:
          print(response.status_code,":  Undefined error while posting to Google Cloud")
   
  #print(response.text)
  #print("this is response")

  resJSON = json.loads(response.text);
  return resJSON;

  #print(resJSON['responses'][0]['customLabelAnnotations'])

  #resultsArr = resJSON['responses'][0]['customLabelAnnotations']
  #print(resultsArr)
  
  #result = resultsArr[0]['label']
  #if (resultsArr[1]['score'] > 0.8) : 
  #   shape = "Blur"
  #else :
   #  shape = "Normal"

  #orientation = resultsArr[2]['label']

  #print(result)
 

  #return result
  #return shape
  #return orientation

  
  

  



#####=========== Function to handle Led's on Image Results ==============##########  

def DisplayLED(inputled):
  if( inputled[0]['score'] > 0.8 ):
     label = inputled[0]['label']
    
    
     if label == "GOOD":
       led(led_green,5)
       print(label) 
       
     else:led(led_red,5)
     print(label) 
    
    
  else:
     label = 'Undetermined'
     print(label) 
     led(led_yellow,5)
     
 
         
 
  led("all",1)

  

#####========== function's to connect mqtt broker=======#####

def on_connect(client, userdata, flags, rc):
    #print("Connected with result code "+str(rc))
    pass

def on_message(client, userdata, message):
    time.sleep(1)
#    print("received message =",str(message.payload.decode("utf-8")))
    ##print(message.topic+" "+str(message.payload))

def on_publish(client, userdata, mid):
    #    print("Published to client", str(client))
    pass

def uploadtoIoT(Thing,ProductObserved,Result,AssemblyOrientation,Assembly_Shape,Assembly_Quality,Bearer_Token,URL,Base64,SerialNo,Logo):
    client= paho.Client("Not Needed") 

####set username and password from cloudmqtt server

    client.username_pw_set(str(username), password= password )

######Bind functions to callback
    client.on_message=on_message
    client.on_connect=on_connect
    client.on_publish=on_publish

#####
#    print("connecting to broker ",broker)
    client.connect(broker, 16988, 60)#connect
    client.loop_start() #start loop to process received messages
 #   print("subscribing ")
    client.subscribe("iot/log/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89")  #subscribe to log
    client.subscribe("iot/ack/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89")  #subscribe to acknowledge
    client.subscribe("iot/push/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89") #subscribe to push
    
    payload = {"mode":"sync","messageType":"baf18c279eb7694bdfb4","messages":[{"Thing":Thing,"ProductObserved":ProductObserved,"Result":Result,"AssemblyOrientation":AssemblyOrientation,"Assembly_Shape":Assembly_Shape,"Assembly_Quality":Assembly_Quality,"Bearer_Token":Bearer_Token,"URL":URL,"Base64":Base64,"SerialNo":SerialNo,"Logo":Logo}]} #Define Payload
  #  print("publishing ")
    client.publish("iot/data/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89", str(payload))#Publish 


    print("Data sent to SAP Leaonardo IoT successfully")
    client.disconnect() #disconnect
    client.loop_stop()

    
    

def AnalyzeLabels(result):
    limit = 0.6
    text=""
    orientation = ['a_90','a_180','a_270','a_90']
    image_quality = ['BLUR','CLEAR']
    assembly_quality = ['GOOD','MISSING_GREEN','MISSING_WHITE']
    out= len(result['responses'][0]['customLabelAnnotations'])

    #print(result)
    labels={}
    labels['assembly_label']="Undetermined"
    labels['image_label']="Normal"
    for x in range(out):
        label= result['responses'][0]['customLabelAnnotations'][x]['label']
        score = result['responses'][0]['customLabelAnnotations'][x]['score']
       
        if (label in orientation ) :
              
              if (score > limit):
                     #labels=labels + ["orientation_label",label,score]
                    labels['orientation_label']=label
                     
        if (label in image_quality ) :
             
              if (score > 0.8):
                     #image_quality_label = label
                     #labels=labels + ["image_quality_label",label,score]
                    labels['image_label']=label
             
                    
                     
        if (label in assembly_quality ) :
              
              if (score > limit):
                     #assembly_quality_label = label
                     #labels=labels + ["assembly_quality_label",label,score]
                     labels['assembly_label']=label
              
    
                     
    #print(labels)
    try :
        
                       
        text=result['responses'][0]['textAnnotations'][0]['description']
        #print(text)
        #text=result['responses'][0]['textAnnotations'][i]['description']
                       
                      
                           
        
                      
        
    
    except :
        text ="NA"
    
    #labels = labels + ["text_detected",text]
    labels['text_detected']=text
    return labels

    

