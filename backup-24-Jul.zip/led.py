import RPi.GPIO as GPIO
import time
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
LED = 18
GPIO.setup(LED,GPIO.OUT)
while True:
    
    print ('LED ON')
    GPIO.output(LED,True)
    time.sleep(3)
    print ('LED OFF')
    GPIO.output(LED,False)
    time.sleep(3)
