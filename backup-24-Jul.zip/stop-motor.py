import time
import FD4LIB

       

print("motor stopped")
FD4LIB.motor("Stop")
      
       




