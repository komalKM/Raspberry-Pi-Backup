import time
import paho.mqtt.client as paho

broker="m13.cloudmqtt.com" #Free CloudMQTT account domain
username = "uctiuqld"      #Username for CloudMQTT Broker
password = "WwQsrtwI15a4"  #Password for CloudMQTT Broker

#define callback
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
def on_message(client, userdata, message):
    time.sleep(1)
    print("received message =",str(message.payload.decode("utf-8")))
    ##print(message.topic+" "+str(message.payload))
def on_publish(client, userdata, mid):
    print("Published to client", str(client))
    
client= paho.Client("Not Needed") 

####set username and password from cloudmqtt server

client.username_pw_set(str(username), password= password )

######Bind functions to callback
client.on_message=on_message
client.on_connect=on_connect
client.on_publish=on_publish

#####
print("connecting to broker ",broker)
client.connect(broker, 16988, 60)#connect
client.loop_start() #start loop to process received messages
print("subscribing ")
client.subscribe("iot/log/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89")  #subscribe to log
client.subscribe("iot/ack/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89")  #subscribe to acknowledge
client.subscribe("iot/push/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89") #subscribe to push
time.sleep(2)
payload = {"mode":"sync","messageType":"baf18c279eb7694bdfb4","messages":[{"Thing":"Visual_S3A","ProductObserved":"Basler_Vision_Kit","Result":"MISSING_GREEN","AssemblyOrientation":"Normal","Assembly_Shape":"Deformed","Assembly_Quality":"Good","Bearer_Token":"123456789","URL":"www.google.com","Base64":"yqguvdjbdjbgfu","SerialNo":"20982364","Logo":"capgemini"}]} #Define Payload
print("publishing ")
client.publish("iot/data/iotmmsp1942077485trial/v1/68190672-0d3b-4d31-a37c-07729dd47a89", str(payload))#Publish 

time.sleep(4)
print("published successfully")
client.disconnect() #disconnect
client.loop_stop() #stop loop
