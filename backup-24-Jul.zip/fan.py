import RPi.GPIO as GPIO
import FD4LIB
import time

Pin = 16

GPIO.setmode(GPIO.BOARD)
GPIO.setup(5,GPIO.OUT)
GPIO.setup(7,GPIO.OUT)
GPIO.setup(11,GPIO.OUT)
GPIO.setup(13,GPIO.OUT)
GPIO.setup(Pin , GPIO.IN, pull_up_down = GPIO.PUD_UP)
GPIO.setwarnings(False)


while True:
    if (0 != GPIO.input(Pin)):
        #time.sleep(5)
        print("Secondary Motor started")
        GPIO.output(5,1)
        GPIO.output(7,0)
        GPIO.output(11,0)
        GPIO.output(13,0)
           
    elif (0 == GPIO.input(Pin)):
        #time.sleep(2)
        print("Primary Motor started")
        GPIO.output(11,1)
        GPIO.output(13,0)
        GPIO.output(5,0)
        GPIO.output(7,0)
        

            