import FD4LIB
import time

print("Primary Motor started")
FD4LIB.motor("Start")
            

while True:
        
        print ('Detecting next product in inspection zone');
        FD4LIB.detectmotion()
        #print ('Next Product Detected.. ');
        FD4LIB.motor("Stop")
        print ('Primary Motor stopped.. ');
        time.sleep(2)
        print ('Backup Motor started.. ');
        FD4LIB.motor("Reverse")
        