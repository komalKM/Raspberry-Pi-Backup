import base64
import requests
import paho.mqtt.client as paho
import time


broker="m13.cloudmqtt.com" #Free CloudMQTT account domain
username = "uctiuqld"      #Username for CloudMQTT Broker
password = "WwQsrtwI15a4"  #Password for CloudMQTT Broker




def convertimage(imagename):
  
    with open(imagename, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read())
    return(encoded_string)

image= convertimage("DCR123.jpg")
convertedtext = str(image)
str1= convertedtext.lstrip("b'")
str2= str1.rstrip("'")

print(image)





def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
def on_message(client, userdata, message):
    time.sleep(1)
    print("received message =",str(message.payload.decode("utf-8")))
    ##print(message.topic+" "+str(message.payload))
def on_publish(client, userdata, mid):
    print("Published to client", str(client))


def uploadtoIoT(InspectionStation,ProductObserved,AssemblyOrientation,Assembly_Shape,Assembly_Quality,Bearer_Token,URL,ImageInBinary,SerialNo,Logo,SerialNoCoordinates,LogoCoordinates):
    client= paho.Client("Not Needed") 

####set username and password from cloudmqtt server

    client.username_pw_set(str(username), password= password )

######Bind functions to callback
    client.on_message=on_message
    client.on_connect=on_connect
    client.on_publish=on_publish

#####
    print("connecting to broker ",broker)
    client.connect(broker, 16988, 60)#connect
    client.loop_start() #start loop to process received messages
    print("subscribing ")
    client.subscribe("iot/log/iotmmsp1941957448trial/v1/23e63ea5-0803-4585-86dd-eb9bf6b924b8")  #subscribe to log
    client.subscribe("iot/ack/iotmmsp1941957448trial/v1/23e63ea5-0803-4585-86dd-eb9bf6b924b8")  #subscribe to acknowledge
    client.subscribe("iot/push/iotmmsp1941957448trial/v1/23e63ea5-0803-4585-86dd-eb9bf6b924b8") #subscribe to push
    
    payload = {"mode":"async","messageType":"4754ae5d973024c0910f","messages":[{"InspectionStation":InspectionStation,"ProductObserved":ProductObserved,"AssemblyOrientation":AssemblyOrientation,"Assembly_Shape":Assembly_Shape,"Assembly_Quality":Assembly_Quality,"Bearer_Token":Bearer_Token,"URL":URL,"ImageInBinary":ImageInBinary,"SerialNo":SerialNo,"Logo":Logo,"SerialNoCoordinates":SerialNoCoordinates,"LogoCoordinates":LogoCoordinates,"FutureUse1":"123","FutureUse2":"123","FutureUse3":"123"}]} #Define Payload
    print("publishing ")
    client.publish("iot/data/iotmmsp1941957448trial/v1/23e63ea5-0803-4585-86dd-eb9bf6b924b8", str(payload))#Publish 


    print("published successfully")
    client.disconnect() #disconnect
    client.loop_stop()

a=uploadtoIoT("Basler Vision Kit","Image","90","Normal","Good","123456","google",str2,"123456","CG","xyx","xyz")
